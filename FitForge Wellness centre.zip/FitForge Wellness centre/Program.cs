﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FitForge_Wellness_centre
{
    class Program
    {
        enum Menu
        {
            InputMemberDetails = 1,
            
            Qualification,
            CountNumberOfQualifedandUnqualifiedMembers,
            DisplayMembersStatistics,
            Exit,
        }

        static string CollectMemberInfo()
        {
            ArrayList members = new ArrayList();

            Console.WriteLine("Please enter your name: ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter your age: ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter membership rank (based on class attendance): ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter date joined as a loyal member (dd/mm/yyyy): ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter number of smoothies purchased: ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter personal best treadmill distance (in km): ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Please enter current employment status (A: Unemployed, B: Employed): ");
            string employmentInput = Console.ReadLine();
            if (employmentInput == "A")
            {
                members.Add("Unemployed");
            }
            else if (employmentInput == "B")
            {
                members.Add("Employed");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter A or B.");
                return null;
            }
            Console.Clear();

            Console.WriteLine("Please enter favourite smoothie flavour: ");
            members.Add(Console.ReadLine());

            Console.Clear();

            Console.WriteLine("Please enter number of smoothies consumed since joining: ");
            members.Add(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Do you want to add another member? (Yes/No): ");
            string addMore = Console.ReadLine();
            if (addMore != "Yes" && addMore != "No")
            {
                Console.WriteLine("Invalid input. Please enter Yes or No.");
                return null;
            }
            Console.Clear();

            // Combine all inputs into a single string
            string result = "Member Info:\n";
            foreach (var item in members)
            {
                result += item + "\n";
            }

            return result;
        }

        static void Qualification()



        {
            ArrayList qualifiedMembers = new ArrayList();
            ArrayList unqualifiedMembers = new ArrayList();
            Console.WriteLine("Are you employed or is your guardian above 18? (Yes/No): ");
            string answer = Console.ReadLine();

            if (answer == "Yes")
            {
                Console.WriteLine("Have you been a member for at least 2 years? (Yes/No): ");
                string answer2 = Console.ReadLine();
                qualifiedMembers.Add("Qualified members who have said no to being employed or having a guardian under 18 : " + answer);

                if (answer2 == "Yes")
                {
                    Console.WriteLine("Do you have a membership rank above 2000, or a treadmill record above 20 km? (Yes/No): ");
                    string answer3 = Console.ReadLine();
                    qualifiedMembers.Add("Qualified members who have said yes to being a member for at least 2 years: " + answer2);

                    if (answer3 == "Yes")
                    {
                        Console.WriteLine("Have you consumed an average of at least 4 smoothies per month? (Yes/No): ");
                        string answer4 = Console.ReadLine();
                        qualifiedMembers.Add("Qualified members who have said yes to having a membership rank above 2000, or a treadmill record above 20km: " + answer3);

                        if (answer4 == "Yes")
                        {
                            Console.WriteLine("How many smoothies have you consumed (per month)?: ");
                            qualifiedMembers.Add("Qualified members who have said yes to having consumed an average of at least 4 smoothies a day: " + answer4);
                            if (int.TryParse(Console.ReadLine(), out int totalSmoothies))
                            {
                                if (totalSmoothies >= 20)
                                {
                                    Console.WriteLine("You do not qualify. The amount of smoothies consumed indicates an unhealthy addiction.");
                                    unqualifiedMembers.Add("Unqualified member with total smoothies: " + totalSmoothies);
                                }
                                else
                                {
                                    Console.WriteLine("Is your favourite smoothie flavour ChocoChurned Chaos? (Yes/No): ");
                                    string answer5 = Console.ReadLine();

                                    if (answer5 == "Yes")
                                    {
                                        Console.WriteLine("You do not qualify. That flavour is linked to unhealthy consumption habits.");
                                        unqualifiedMembers.Add("Unqualified members who have said yes to their favourite flavour being ChocoChurned Chaos : " + answer5);
                                    }
                                    else if (answer5 == "No")
                                    {
                                        Console.WriteLine("You are qualified for the membership.");
                                        qualifiedMembers.Add("Qualified members who have said no to their favourite flavour being ChocoChurned Chaos: " + answer5);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input. Please enter Yes or No.");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter a number for total smoothies.");
                            }
                        }
                        else if (answer4 == "No")
                        {
                            Console.WriteLine("You are not qualified for the membership.");
                            unqualifiedMembers.Add("Unqualified members who have said no to consuming an average of at least 4 smoothies per month : " + answer4);
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Please enter Yes or No.");
                        }
                    }
                    else if (answer3 == "No")
                    {
                        Console.WriteLine("You are not qualified for the membership.");
                        unqualifiedMembers.Add("Unqualified members who have said no to having a membership rank above 2000, or a treadmill record above 20 km : " + answer3);
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter Yes or No.");
                    }
                }
                else if (answer2 == "No")
                {
                    Console.WriteLine("You are not qualified for the membership.");
                    unqualifiedMembers.Add("Unqualified members who have less than 2 years of being a member : " + answer2);
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter Yes or No.");
                }
            }
            else if (answer == "No")
            {
                Console.WriteLine("You are not qualified for the membership.");
                unqualifiedMembers.Add("Unqualified members who have said no to them being employed or their guardian being under 18 : " + answer);
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter Yes or No.");
            }
            Console.WriteLine("\n--- Qualified Members ---");
            foreach (var member in qualifiedMembers)
            {
                Console.WriteLine(member);
            }

            Console.WriteLine("\n--- Unqualified Members ---");
            foreach (var member in unqualifiedMembers)
            {
                Console.WriteLine(member);
            }

           







        }
        static void CountQualifiedAndUnqualifiedMembers(ArrayList qualifiedMembers, ArrayList unqualifiedMembers)
        {
            Console.WriteLine($"Number of qualified members: {qualifiedMembers.Count}");
            Console.WriteLine($"Number of unqualified members: {unqualifiedMembers.Count}");
        }






        static void Main(string[] args)
        {
            ArrayList qualifiedMembers = new ArrayList();
            ArrayList unqualifiedMembers = new ArrayList();



            while (true)
        {
            Console.WriteLine("Select an option:");
            foreach (var option in Enum.GetValues(typeof(Menu)))
            {
                Console.WriteLine($"{(int)option}. {option}");
            }

            if (int.TryParse(Console.ReadLine(), out int choice) && Enum.IsDefined(typeof(Menu), choice))
            {
                Menu selectedMenu = (Menu)choice;

                switch (selectedMenu)
                {
                    case Menu.InputMemberDetails:
                        CollectMemberInfo();
                        Console.WriteLine("Member details collected successfully.");

                        break;
                            

                        

                        case Menu.Qualification:
                            Console.Clear();
                            Qualification();
                            Console.WriteLine("Member qualifies for the wellness reward credit");
                            break;

                        case Menu.CountNumberOfQualifedandUnqualifiedMembers:
                            Console.Clear();
                            CountQualifiedAndUnqualifiedMembers(qualifiedMembers, unqualifiedMembers);
                            break;


                            

                    case Menu.DisplayMembersStatistics:
                        Console.WriteLine("Displaying members' statistics...");
                        break;

                    case Menu.Exit:
                       
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid number from the menu.");
            }

            Console.WriteLine(); 
        }
    }
            }
        }
       
    

